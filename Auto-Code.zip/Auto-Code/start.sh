#! /bin/bash
jar -jar auto-code-1.0.jar